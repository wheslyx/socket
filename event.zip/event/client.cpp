#include "rocket.h"
#define TXPORT 5010
#define RXPORT 5011
#define MAXLINE 18 
int main() {
	
	std::string ip = "0.0.0.0"; // please write server IP
	
	std::cout << "communication parameters (mode, port, ip) " << std::endl; // parameters
	std::cout << "Modes are " << std::endl; // These are modes
	std::cout << "0: Only Read " << std::endl;
    std::cout << "1: Only Send " << std::endl;
    std::cout << "2: Read & Send" << std::endl;

	float response;

	float startf= 1001000.f;

	unsigned long long data;

	int header = 999; // packet header
	uint8_t event =rand() % 2; // packet event is 0 for no fatigue and 1 for fatigue
	unsigned char starT[MAXLINE] = "THE END";
	unsigned char *footer = starT; // packet feet
	
	printf("event = %d \n",event);

	rocket communication(1, (int) TXPORT, ip);
	communication.rkt_writefloat(&startf);

	communication.rkt_packetlong(&data); // this is data packet from Control Screen
	std::cout << "received " << data << std::endl;

	communication.rkt_writeint(&header);
	communication.rkt_writeuint8( &event);
	communication.rkt_writeChar(footer, (int) MAXLINE);
	std::cout << "Confirmation Sent" << std::endl;

	communication.rkt_finalize();

}