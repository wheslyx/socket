#include "rocket.h"
#define RXPORT  5010
#define TXPORT  5011
#define MAXLINE 18

int main() {
	
	std::string ip = "0.0.0.0"; // Please set IP or else 0.0.0.0 is broadcast
	std::cout << "communication parameters (mode, port, ip) " << std::endl; // parameters
	std::cout << "Modes are " << std::endl; // These are modes
	std::cout << "0: Only Read " << std::endl;
    std::cout << "1: Only Send " << std::endl;
    std::cout << "2: Read & Send" << std::endl;

    float response = 25.0;
	float start = 1.0; 
	int header;
	uint8_t event;
	long long unsigned data = 221345878677565343;
	unsigned long len = sizeof(unsigned long);

	unsigned char buffer[MAXLINE];

	rocket communication(0, (int) RXPORT, ip);
	
	communication.rkt_packetfloat(&start);
	std::cout << "Start " << start << std::endl;

	communication.rkt_writelong(&data,len);
	std::cout << "sent " << data << std::endl;

	communication.rkt_packetint(&header);
	std::cout << "header " << header << std::endl;
	communication.rkt_packetuint8(&event);
	std::cout << "event " << event << std::endl;
	communication.rkt_packetChar(buffer);
	std::cout << "footer " << buffer << std::endl;

}